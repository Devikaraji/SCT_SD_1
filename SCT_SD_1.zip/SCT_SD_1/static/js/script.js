document.getElementById('convertButton').addEventListener('click', function () {
    const value = parseFloat(document.getElementById('tempValue').value);
    const fromUnit = document.getElementById('fromUnit').value;
    const toUnit = document.getElementById('toUnit').value;

    if (isNaN(value)) {
        document.getElementById('result').innerText = 'Please enter a valid number';
        return;
    }

    fetch('http://127.0.0.1:5000/convert', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            value: value,
            from_unit: fromUnit,
            to_unit: toUnit
        }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.result !== undefined) {
            document.getElementById('result').innerText = `Converted: ${data.result} ${toUnit}`;
        } else {
            document.getElementById('result').innerText = `Error: ${data.error || 'Unknown error'}`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('result').innerText = 'Conversion failed. Check server.';
    });
});
