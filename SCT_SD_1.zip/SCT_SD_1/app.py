# Import necessary modules from Flask
from flask import Flask, request, jsonify
# Import CORS to handle cross-origin requests from the frontend
from flask_cors import CORS

# Initialize the Flask application
app = Flask(__name__)
# Enable CORS for all routes, allowing the frontend to make requests
CORS(app)

# --- Temperature Conversion Functions (from your original code) ---
def celsius_to_fahrenheit(c):
    """Converts Celsius to Fahrenheit."""
    return (c * 9/5) + 32

def celsius_to_kelvin(c):
    """Converts Celsius to Kelvin."""
    return c + 273.15

def fahrenheit_to_celsius(f):
    """Converts Fahrenheit to Celsius."""
    return (f - 32) * 5/9

def fahrenheit_to_kelvin(f):
    """Converts Fahrenheit to Kelvin."""
    return (f - 32) * 5/9 + 273.15

def kelvin_to_celsius(k):
    """Converts Kelvin to Celsius."""
    return k - 273.15

def kelvin_to_fahrenheit(k):
    """Converts Kelvin to Fahrenheit."""
    return (k - 273.15) * 9/5 + 32

# --- API Endpoint for Temperature Conversion ---
@app.route('/convert', methods=['POST'])
def convert_temperature():
    """
    Handles POST requests for temperature conversion.
    Expects JSON input with 'temperature', 'from_unit', and 'to_unit'.
    Returns JSON with 'converted_temperature' or an error message.
    """
    try:
        # Get JSON data from the request body
        data = request.get_json()

        # Extract temperature value and units
        temperature = data.get('temperature')
        from_unit = data.get('from_unit')
        to_unit = data.get('to_unit')

        # Validate input data
        if not all([temperature is not None, from_unit, to_unit]):
            return jsonify({'error': 'Missing temperature, from_unit, or to_unit'}), 400
        if not isinstance(temperature, (int, float)):
            return jsonify({'error': 'Temperature must be a number'}), 400
        if from_unit not in ['celsius', 'fahrenheit', 'kelvin'] or \
           to_unit not in ['celsius', 'fahrenheit', 'kelvin']:
            return jsonify({'error': 'Invalid unit specified. Use celsius, fahrenheit, or kelvin.'}), 400

        # Perform conversion logic
        # Convert to Celsius first for intermediate calculation
        temp_in_celsius = temperature
        if from_unit == 'fahrenheit':
            temp_in_celsius = fahrenheit_to_celsius(temperature)
        elif from_unit == 'kelvin':
            temp_in_celsius = kelvin_to_celsius(temperature)

        # Convert from Celsius to the target unit
        converted_temp = temp_in_celsius
        if to_unit == 'fahrenheit':
            converted_temp = celsius_to_fahrenheit(temp_in_celsius)
        elif to_unit == 'kelvin':
            converted_temp = celsius_to_kelvin(temp_in_celsius)

        # Return the converted temperature as JSON
        return jsonify({'converted_temperature': converted_temp}), 200

    except Exception as e:
        # Catch any unexpected errors and return a 500 Internal Server Error
        return jsonify({'error': str(e)}), 500

# Run the Flask application
if __name__ == '__main__':
    # Run on all available interfaces (0.0.0.0) and port 5000
    # In a production environment, you would use a more robust WSGI server like Gunicorn
    app.run(debug=True, host='0.0.0.0', port=5000)
